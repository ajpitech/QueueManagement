﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppQueueManagementUser
{
   
        public class ServiceBranchId
        {
            public string BranchName { get; set; }
            public string CompanyName { get; set; }
        }
    
}
