﻿using ConsoleAppQueueManagementAgent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppQueueManagementAgent    
{
    internal class ServingStatus:Page
    {
        public ServingStatus(Page previous)
        {
            PageName = "Serving Status Page";
            PreviousPage = previous;
        }
        public override void Menu()
        {
            
        }
    }
}
