﻿using ConsoleAppQueueManagementAgent;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppQueueManagementAgent
{
    internal class GetAnswers:Page
    {
        public GetAnswers(Page previous)
        {
            PageName = "Get Answers Page";
            PreviousPage = previous;
        }
        public override void Menu()
        {
            GetAns();
        }
        public void GetAns()
        {
            string Tokenno = consolereader.getstring("Please Enter Token no :- ");
            string query = "exec GetAnswer '"+Tokenno+"'";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                int counter = 1;
                while (reader.Read())
                {
                    if (counter == 1)
                    { 
                    Console.WriteLine("{0,-30}{1}", "Question", "FullAnswer");
                    }
                    Console.Write(counter + ". {0,-30}{1}", reader["Question"].ToString(), reader["FullAnswer"].ToString());
                    Console.WriteLine();
                    counter++;
                }
                reader.Close(); 
            }
            else
            {
                Console.WriteLine("Your Token no is " + Tokenno + "... Invalid");
            }
            con.Close();

        }
        //GetAnswer 'm-20'
    }
}
